<?php
/**
* Plugin Name: Project Safe
* Plugin URI: http://wpress.top
* Description: Project Safe, sistemde IP adresi kayıtlı olmayan kişilerin WP-Admin dizinine girişini engelleyen ve WP-Admin'e giriş izni bulunan herkesi kontrol altında tutarak Wordpress açıklarından etkilenmemenizi sağlayan bir eklentidir.
* Version: 2.0
* Author: Webellek
* Author URI: https://webellek.com
* License: GPL
*/
	function gip(){
		if(getenv("HTTP_CLIENT_IP")) {
			$ip = getenv("HTTP_CLIENT_IP");
		} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
			$ip = getenv("HTTP_X_FORWARDED_FOR");
 		if (strstr($ip, ',')) {
 			$tmp = explode (',', $ip);
 			$ip = trim($tmp[0]);
 		}
		} else {
			$ip = getenv("REMOTE_ADDR");
		}
		error_reporting(0);
		session_start();
		$_SESSION["ip"] = $ip;
		}
	
	function psinc(){
		include "wp-content/plugins/project-safe/psa.php";
		$_SESSION["psa"] = $psa;
	}
	
	function psincw(){
		include "../wp-content/plugins/project-safe/psa.php";
		$_SESSION["psa"] = $psa;
	}
		
	function logk() { 
		$psad = $_SESSION["psa"];
		$ipdosyasi = "$psad/kayit/".$_SESSION["ip"].".txt";
		if (!file_exists($ipdosyasi)) {			
			include "$psad/func/iset.php";
			echo "<meta http-equiv='refresh' content='0; url=http://".$_SERVER['SERVER_NAME']."/".$isetdizin."' />";
			die();
		}
	}
	
	function admk(){
		$psad = $_SESSION["psa"];	
		if (file_exists("../$psad/func/abir.txt") && !file_exists("../$psad/kayit/".$_SESSION["ip"].".txt")) {
			include "../$psad/func/wpset.php";
			echo "<meta http-equiv='refresh' content='0; url=http://".$_SERVER['SERVER_NAME']."/".$wpsetdizin."' />";
			die();
		}	
		}	

add_action('login_head', 'gip');
add_action('login_head', 'psinc');
add_action('login_head', 'logk');
add_action('admin_init', 'gip');
add_action('admin_init', 'psincw');
add_action('admin_init', 'admk');
?>